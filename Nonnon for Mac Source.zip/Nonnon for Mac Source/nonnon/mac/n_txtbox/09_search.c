// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@implementation NonnonTxtbox (NonnonTxtboxSearch)


- (void) NonnonTxtboxSearch:(n_posix_char*) query
{

	if ( ( query[ 0 ] == n_posix_literal( '#' ) )&&( n_string_is_digit( query, 1 ) ) )
	{

		caret_fr = caret_to = n_txtbox_caret_detect_cch2pixel
		(
			n_txt_data,
			n_posix_atoi( &query[ 1 ] ) - 1,
			font,
			font_size,
			0
		);

		[self NonnonTxtboxCaretOutOfCanvasUpDownSearch];

		[self display];

	} else {
//NSLog( @"%ld", labs( caret_fr.cch.y - caret_to.cch.y ) );

		if ( 0 != labs( caret_fr.cch.y - caret_to.cch.y ) ) { return; }

		n_type_int caret_f = MIN( caret_fr.cch.x, caret_to.cch.x );
		n_type_int caret_t = MAX( caret_fr.cch.x, caret_to.cch.x );
		
		n_type_int y = caret_fr.cch.y;
		n_posix_loop
		{//break;

			n_string_search( n_txt_get( n_txt_data, y ), query, &caret_f, &caret_t );
			if ( caret_f != caret_t ) { break; }

			caret_f = caret_t = 0;

			y++;
			if ( y >= n_txt_data->sy ) { y = 0; break; }
		}

		caret_fr = n_txtbox_caret_detect_cch2pixel
		(
			n_txt_data,
			y,
			font,
			font_size,
			caret_f
		);

		caret_to = n_txtbox_caret_detect_cch2pixel
		(
			n_txt_data,
			y,
			font,
			font_size,
			caret_t
		);

		[self NonnonTxtboxCaretOutOfCanvasUpDownSearch];

		shift_selection_is_tail = TRUE;

		[self display];

	}


	return;
}


@end

