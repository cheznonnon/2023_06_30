// nmidi
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Link : -lwinmm




#ifndef _H_NONNON_WIN32_GAME_HMIDIOUT
#define _H_NONNON_WIN32_GAME_HMIDIOUT




#include  "../neutral/posix.c"


#include <mmsystem.h>

#ifdef _MSC_VER
#pragma comment( lib, "winmm" )
#endif // #ifdef _MSC_VER




#define N_HMIDIOUT_VOLUME_MAX    ( 127 )

#define N_HMIDIOUT_PANPOT_LEFT   (   0 )
#define N_HMIDIOUT_PANPOT_CENTER (  64 )
#define N_HMIDIOUT_PANPOT_RIGHT  ( 127 )




static HMIDIOUT n_hmidiout_hmo      = NULL;
static int      n_hmidiout_refcount = 0;




void
n_hmidiout_exit( void )
{

	if ( n_hmidiout_refcount >= 1 ) { n_hmidiout_refcount--; }

	if ( n_hmidiout_refcount != 0 ) { return; }

	if ( n_hmidiout_hmo != NULL )
	{
		midiOutClose( n_hmidiout_hmo );
		n_hmidiout_hmo = NULL;
	}


	return;
}

void
n_hmidiout_init( void )
{

	if ( n_hmidiout_refcount < INT_MAX )
	{

		if ( n_hmidiout_hmo == NULL )
		{
			midiOutOpen( &n_hmidiout_hmo, MIDI_MAPPER, 0,0, CALLBACK_NULL );
		}

		n_hmidiout_refcount++;

	}


	return;
}

int
n_hmidiout_msg( int event, int channel, int p1, int p2 )
{
	return ( ( event | channel ) | ( p1 << 8 ) | ( p2 << 16 ) );
}

void
n_hmidiout_sound( int channel, int sound )
{

	int msg = n_hmidiout_msg( 0xc0, channel, sound, 0 );

	midiOutShortMsg( n_hmidiout_hmo, msg );


	return;
}

void
n_hmidiout_panpot( int channel, int panpot )
{

	int msg = n_hmidiout_msg( 0xb0, channel, 10, panpot );

	midiOutShortMsg( n_hmidiout_hmo, msg );


	return;
}

void
n_hmidiout_note( int channel, int note, int volume )
{

	// [!] : Vista or later : note-on with volume zero : a sound keeps on ringing

	int msg;

	if ( volume == 0 )
	{
		msg = n_hmidiout_msg( 0xb0, channel,  120, volume );
	} else {
		msg = n_hmidiout_msg( 0x90, channel, note, volume );
	}

	midiOutShortMsg( n_hmidiout_hmo, msg );


	return;
}

void
n_hmidiout_all( int channel, int sound, int panpot, int note, int volume )
{

	n_hmidiout_sound( channel, sound );
	n_hmidiout_panpot( channel, panpot );
	n_hmidiout_note( channel, note, volume );


	return;
}


#endif // _H_NONNON_WIN32_GAME_HMIDIOUT

