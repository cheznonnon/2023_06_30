// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html




#ifndef _H_NONNON_WIN32_EXPLORER
#define _H_NONNON_WIN32_EXPLORER




#include "../neutral/dir.c"
#include "../neutral/filer.c"
#include "../neutral/ini.c"
#include "../neutral/string_path.c"

#include "./sysinfo/version.c"
#include "./win/_debug.c"
#include "./win/gui.c"
#include "./win/commandline.c"
#include "./win/control.c"
#include "./win/cursor.c"
#include "./registry.c"


#include <shlobj.h>




n_posix_bool
n_explorer_recyclebin( HWND hwnd, const n_posix_char *fname )
{

	// [MSDN] : multi-path available
	//
	//	"fname" need to have double-NUL("\0\0") 

	SHFILEOPSTRUCT sfo; n_memory_zero( &sfo, sizeof( SHFILEOPSTRUCT ) );

	sfo.hwnd   = hwnd;
	sfo.wFunc  = FO_DELETE;
	sfo.pFrom  = fname;
	sfo.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION;

	int ret = SHFileOperation( &sfo );


	return ( ret != 0 );
}

void
n_explorer_open( const n_posix_char *name, int sw )
{

	n_type_int    cch = 0;
	n_posix_char *exe = NULL;


	if ( n_string_is_empty( name ) )
	{

		// [!] : call "My Computer"

		const n_posix_char *exp = n_posix_literal( "explorer.exe /n,::{20D04FE0-3AEA-1069-A2D8-08002B30309D}" );

		cch = n_posix_strlen( exp );
		exe = n_string_new( cch );

		n_string_copy( exp, exe );

	} else
	if ( n_string_is_same( N_STRING_DOT, name ) )
	{

		const n_posix_char *exp = n_posix_literal( "explorer.exe ." );

		cch = n_posix_strlen( exp );
		exe = n_string_new( cch );

		n_string_copy( exp, exe );

	} else
	if ( n_posix_stat_is_exist( name ) )
	{

		const n_posix_char *exp = n_posix_literal( "explorer.exe /n,/select,\"%s\"" );

		cch = n_posix_strlen( exp ) + n_posix_strlen( name );
		exe = n_string_new( cch );

		n_posix_sprintf( exe, exp, name );

	} else {

		return;

	}


	n_win_execute( exe, sw, n_posix_true );


	n_string_free( exe );


	return;
}

void
n_explorer_property( const n_posix_char *name )
{

	if ( n_string_is_empty( name ) )
	{

		// [!] : call "System Properties"

		// [!] : Win95 : ShellExecute() doesn't function

		n_posix_char *str = NULL;

		if ( n_sysinfo_version_vista_or_later() )
		{
			const n_posix_char *ctl = n_posix_literal( "control.exe /name Microsoft.System" );
			str = n_string_carboncopy( ctl );
		} else {
			const n_posix_char *ctl = n_posix_literal( "control.exe sysdm.cpl" );
			str = n_string_carboncopy( ctl );
		}

		n_win_exec( str, SW_NORMAL );

		n_string_free( str );

//ShellExecute( game.hwnd, NULL, n_posix_literal( "sysdm.cpl" ), NULL, NULL, SW_SHOWNORMAL );
//n_win_exec_literal( "sysdm.cpl", SW_NORMAL );

	} else {

		SHELLEXECUTEINFO sei; ZeroMemory( &sei, sizeof( SHELLEXECUTEINFO ) );

		sei.cbSize = sizeof( SHELLEXECUTEINFO );
		sei.fMask  = SEE_MASK_INVOKEIDLIST;
		sei.lpVerb = n_posix_literal( "properties" );
		sei.lpFile = name;
		sei.nShow  = SW_SHOWNORMAL;

		ShellExecuteEx( &sei );

	}


	return;
}

void
n_explorer_SHGetFolderPath( int csidl, n_posix_char *ret )
{

	HMODULE hmod = LoadLibrary( n_posix_literal( "Shell32.dll" ) );

#ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "SHGetFolderPathW" );
#else  // #ifdef UNICODE
	FARPROC func = GetProcAddress( hmod, "SHGetFolderPathA" );
#endif // #ifdef UNICODE

	if ( func != NULL )
	{
		func( NULL, csidl, NULL, 0, ret );
	}

	FreeLibrary( hmod );


	return;
}

void
n_explorer_iconcache_remove( void )
{

	// [!] : Win9x / NT4.0

	{

		// [MSDN] : use MAX_PATH or larger

		const n_posix_char *iconcache = n_posix_literal( "ShellIconCache" );

		n_posix_char *path = n_string_path_new( MAX_PATH + 1 + n_posix_strlen( iconcache ) );

		GetWindowsDirectory( path, MAX_PATH );

		n_string_path_make( path, iconcache, path );
//n_posix_debug_literal( " 1 : %s ", path );

		n_filer_remove( path );

		n_string_path_free( path );

	}

	{

		// [MSDN] : use MAX_PATH or larger

		const n_posix_char *iconcache = n_posix_literal( "IconCache.db" );

		n_posix_char *path = n_string_path_new( MAX_PATH + 1 + n_posix_strlen( iconcache ) );

		int n_CSIDL_LOCAL_APPDATA = 28;
		n_explorer_SHGetFolderPath( n_CSIDL_LOCAL_APPDATA, path );

		n_string_path_make( path, iconcache, path );
//n_posix_debug_literal( " 2 : %s ", path );

		n_filer_remove( path );

		n_string_path_free( path );

	}

	{

		// [MSDN] : use MAX_PATH or larger

		const n_posix_char *iconcache = n_posix_literal( "Microsoft\\Windows\\Explorer" );

		n_posix_char *path = n_string_path_new( MAX_PATH + 1 + n_posix_strlen( iconcache ) );

		int n_CSIDL_LOCAL_APPDATA = 28;
		n_explorer_SHGetFolderPath( n_CSIDL_LOCAL_APPDATA, path );

		n_string_path_make( path, iconcache, path );
//n_posix_debug_literal( " 3 : %s ", path );

		n_dir dir; n_dir_zero( &dir );

		if ( n_posix_false == n_dir_load( &dir, path ) )
		{

			n_type_int i = dir.dir;
			n_posix_loop
			{
				if ( i >= n_dir_all( &dir ) ) { break; }

				if ( n_string_path_ext_is_same_literal( ".db\0\0", n_dir_name( &dir, i ) ) )
				{
//n_posix_debug_literal( " %s ", n_dir_name( &dir, i ) );
					n_filer_remove( n_dir_name( &dir, i ) );
				}

				i++;
			}

		}
		

		//n_filer_remove( path );

		n_string_path_free( path );

	}


	return;
}

void
n_explorer_refresh( n_posix_bool refresh_icon )
{

	// [!] : Win95
	//
	//	SHCNF_PATH is needed
	//	Explorer will crash when p1 is NULL
	//
	//	this alternative logic is available
	//	SendMessage( HWND_BROADCAST, WM_KEYDOWN, VK_F5, 0 );
	//	SendMessage( HWND_BROADCAST, WM_KEYUP,   VK_F5, 0 );

	// [!] : Win98 : Explorer will never synchronize
	//
	//	SHCNE_ASSOCCHANGED only can redraw icons
	//	Explorer do nothing when SHCNF_PATH is set
	//
	//	this alternative logic is NOT available
	//	SendMessage( HWND_BROADCAST, WM_KEYDOWN, VK_F5, 0 );
	//	SendMessage( HWND_BROADCAST, WM_KEYUP,   VK_F5, 0 );

	// [!] : SHCNE_ASSOCCHANGED
	//
	//	this includes the same effects of SHCNE_ALLEVENTS

	// [!] : SHCNE_DISKEVENTS
	//
	//	SHCNE_RENAMEITEM | SHCNE_CREATE | HCNE_DELETE
	//	SHCNE_MKDIR | SHCNE_RMDIR
	//	SHCNE_ATTRIBUTES
	//	SHCNE_UPDATEDIR | SHCNE_UPDATEITEM
	//	SHCNE_RENAMEFOLDER

	// [!] : SHCNF_NOTIFYRECURSIVE 0x00010000
	//
	//	MinGW header has not this

	// [!] : Vista or later : SHChangeNotify() is ignored
	//
	//	.LNK made by older Windows causes this problem


	LONG shcne;
	UINT shcnf;
	void *p1, *p2;


	if ( refresh_icon )
	{

		n_explorer_iconcache_remove();

		shcne = SHCNE_ASSOCCHANGED;
		shcnf = SHCNF_IDLIST | SHCNF_FLUSHNOWAIT;
		p1    = NULL;
		p2    = NULL;

	} else {

		if ( n_sysinfo_version_95() )
		{

			shcne = SHCNE_ALLEVENTS;
			shcnf = SHCNF_PATH | SHCNF_FLUSHNOWAIT;
			p1    = ".\\";
			p2    = NULL;

		} else {

			shcne = SHCNE_ALLEVENTS;
			shcnf = SHCNF_FLUSHNOWAIT;
			p1    = NULL;
			p2    = NULL;

		}

	}


	SHChangeNotify( shcne, shcnf, p1, p2 );


	return;
}

#define n_explorer_path_get_cch( hwnd_explorer ) ( MAX_PATH )

void
n_explorer_path_get( HWND hwnd_explorer, n_posix_char *ret, n_type_int ret_length )
{

	// [Mechanism] : Cheap solution for drag and drop into Explorer Window
	//
	//	OLE Drag Drop is too complicated
	//	OLE Clipboard handling is needed
	//	Vista or later : SHCreateDataObject() may be available


	if ( ret == NULL ) { return; } else { n_string_truncate( ret ); }


	HWND h = NULL;

	if ( hwnd_explorer != NULL )
	{
		h = hwnd_explorer;
	} else {
		//h = n_win_cursor2hwnd();
	}

	h = n_win_hwnd_toplevel( h );


	// [!] : Win8 or later : "WorkerW" is possible

	if (
		( n_win_class_is_same_literal( h, ""        ) )
		||
		( n_win_class_is_same_literal( h, "Progman" ) )
		||
		( n_win_class_is_same_literal( h, "WorkerW" ) )
	)
	{

		// IE 5 or later is needed

		//DWORD n_FOLDERID_Desktop = ( (DWORD) TEXT( "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}" ) );
		//SHGetFolderPath( NULL, CSIDL_DESKTOP, NULL, FOLDERID_Desktop, ret );


		// IE 4 or later is needed

		//SHGetSpecialFolderPath( NULL, ret, CSIDL_DESKTOP, n_posix_false );


		// IE 4 or later : SHGetSpecialFolderLocation()

		//ITEMIDLIST *pidl = NULL;

		//SHGetSpecialFolderLocation( NULL, CSIDL_DESKTOP, &pidl );
		//SHGetPathFromIDList( pidl, ret );
		//CoTaskMemFree( pidl );


		ITEMIDLIST idl; ZeroMemory( &idl, sizeof( ITEMIDLIST ) );
		SHGetPathFromIDList( &idl, ret );


		return;

	}

//h = n_win_hwnd_find_literal( NULL, "CabinetWClass" );


	// [!] : XP or ealier : "ExploreWClass" is possible

	if (
		( n_posix_false == n_win_class_is_same_literal( h, "CabinetWClass" ) )
		&&
		( n_posix_false == n_win_class_is_same_literal( h, "ExploreWClass" ) )
	)
	{
		return;
	}


	// [!] : be careful

	n_posix_bool ret_onoff = ( ( ret != NULL )&&( ret_length >= 2 ) );


	// [!] : shared in all version : followed by a folder option setting

	if ( ret_onoff )
	{
		n_win_text_get( h, ret, (int) ret_length - 1 );
//n_posix_debug( ret );
		if ( n_string_path_is_abspath( ret ) ) { return; }
	}


	// Fallback

	if ( n_sysinfo_version_vista_or_later() )
	{

		h = n_win_hwnd_find_literal( h, "WorkerW"           );
		h = n_win_hwnd_find_literal( h, "ReBarWindow32"     );
		h = n_win_hwnd_find_literal( h, "Address Band Root" );
		h = n_win_hwnd_find_literal( h, "msctls_progress32" );
		h = n_win_hwnd_find_literal( h, "Breadcrumb Parent" );
		h = n_win_hwnd_find_literal( h, "ToolbarWindow32"   );

		if ( h == NULL ) { return; }


		// [!] : "Address: C:\folder"

		if ( ret_onoff )
		{

			n_win_text_get( h, ret, (int) ret_length - 1 );
//n_posix_debug_literal( "%s", ret );

			n_type_int i = 0;
			n_posix_loop
			{

				if ( ret[ i ] == N_STRING_CHAR_SPACE )
				{
					n_string_copy( &ret[ i + 1 ], ret );
					break;
				}

				i++;
				if ( ret[ i ] == N_STRING_CHAR_NUL ) { break; }
			}

		}

		if ( ret_onoff )
		{
			if ( n_string_path_is_abspath( ret ) ) { return; }
		}

	} else
	if ( n_posix_false == n_sysinfo_version_95() )
	{

		// [!] : followed by a folder option setting : "full path in an addressbar"

		// [!] : you can get a path name even if under these cases
		//
		//	a : address bar is hidden
		//	b : IE6 : rebar controls are locked
		//	c : address field is empty by user input

		n_string_truncate( ret );

		HWND hwnd_worker = n_win_hwnd_find_literal( h, "WorkerA" );
		if ( hwnd_worker == NULL )
		{
			hwnd_worker = n_win_hwnd_find_literal( h, "WorkerW" );
		}

		h = hwnd_worker;
		h = n_win_hwnd_find_literal( h, "ReBarWindow32" );
		h = n_win_hwnd_find_literal( h, "ComboBoxEx32"  );
		h = n_win_hwnd_find_literal( h, "ComboBox"      );
		h = n_win_hwnd_find_literal( h, "Edit"          );

		// [!] : all version : not function : n_win_text_get( h, ret, ret_length - 1 );

		// [x] : Win98 : crash or empty string will be returned

		if ( ret_onoff )
		{

			if ( n_posix_false == n_sysinfo_version_98() )
			{
				n_win_edit_line_get( h, 0, ret, (int) ret_length );
			}

			if ( n_string_path_is_abspath( ret ) ) { return; }

		}

	}


	// Overkilled Fallback 2

	if (
		( n_sysinfo_version_vista_or_later() )
		&&
		( n_posix_false == n_posix_stat_is_exist( ret ) )
	)
	{

		// [!] : try to handle as Library

		n_posix_char *str_ret;

		if (
			( n_posix_false == n_string_path_is_abspath( ret ) )
			&&
			( n_string_search_simple( ret, N_POSIX_SLASH ) )
		)
		{

			// [!] : "Library\Name" : add dummy drive name, then extract the last name

			n_posix_char *drive = n_posix_literal( "C:\\" );
			n_posix_char *str   = n_string_path_make_new( drive, ret );

			str_ret = n_string_path_name_new( str );

			n_string_path_free( str );

		} else {

			str_ret = n_string_path_carboncopy( ret );

		}
//n_posix_debug_literal( "%s", str_ret ); n_string_path_free( str_ret );


		// [MSDN] : use MAX_PATH or larger

		//const int n_CSIDL_PERSONAL = 5; // C:\Users\UserName\Documents
		const int n_CSIDL_PROFILE  = 40; // C:\Users\UserName

		n_posix_char *path = n_string_path_new( MAX_PATH );
		n_explorer_SHGetFolderPath( n_CSIDL_PROFILE, path );
//n_posix_debug_literal( "%s", path );


		n_dir dir; n_dir_zero( &dir ); n_dir_load( &dir, path );

		n_type_int i = 0;
		n_posix_loop
		{//break;

			if ( i >= n_dir_all( &dir ) ) { break; }


			const n_posix_char *folder = n_dir_path( &dir, i );
			const n_posix_char *file   = n_dir_name( &dir, i );


			n_posix_char *name = n_string_path_make_new( folder, file );

			n_posix_bool is_done = n_posix_false;

			if ( n_posix_stat_is_dir( name ) )
			{
//n_posix_debug_literal( " %s ", name );

				// [!] : try to load "Desktop.ini"

				const n_posix_char *desktop_ini = n_posix_literal( "Desktop.ini" );

				n_posix_char *name_desktop_ini = n_string_path_make_new( name, desktop_ini );
//n_posix_debug_literal( "Desktop.ini : %s", name_desktop_ini );


				n_ini ini; n_ini_zero( &ini ); n_ini_load( &ini, name_desktop_ini );

				const n_posix_char *section = n_posix_literal( ".ShellClassInfo"       );
				const n_posix_char *lval    = n_posix_literal( "LocalizedResourceName" );

				n_posix_char *rval = n_ini_value_str_new( &ini, section, lval, N_STRING_EMPTY );

				n_ini_free( &ini );
//n_posix_debug_literal( "RVal : %s", rval );


				n_string_path_free( name_desktop_ini );


				n_posix_char *str_resource_number = n_string_new( n_posix_strlen( rval ) );

				n_string_parameter( rval, N_STRING_COMMA, NULL, 1, str_resource_number );
				n_type_int resource_number = abs( n_posix_atoi( str_resource_number ) );
//n_posix_debug_literal( " %s : %s ", desktop_ini, str_resource_number );

				n_string_free( str_resource_number );

				n_string_path_free( rval );


				HMODULE hmod = LoadLibrary( n_posix_literal( "Shell32.dll" ) );

				n_type_int    cch_localized_name = n_posix_strlen( str_ret );
				n_posix_char *str_localized_name = n_string_path_new( cch_localized_name );
				LoadString( hmod, (UINT) resource_number, str_localized_name, (int) cch_localized_name + 2 );

				FreeLibrary( hmod );

//n_posix_debug_literal( " %s\n %s ", str_ret, str_localized_name );
				if ( n_string_is_same( str_ret, str_localized_name ) )
				{
					n_string_path_make( folder, file, ret );
					is_done = n_posix_true;
				}

				n_string_path_free( str_localized_name );

			}

			n_string_path_free( name );

			if ( is_done ) { break; }

			i++;

		} // n_posix_loop

		n_dir_free( &dir );

		n_string_path_free( str_ret );

	}


	if ( ret_onoff )
	{
		if ( n_posix_false == n_posix_stat_is_exist( ret ) )
		{
			n_string_truncate( ret );
		}
	}


	return;
}

n_posix_char*
n_explorer_path_new( HWND hwnd_explorer )
{

	// [!] : you need to n_string_path_free() a returned variable

	n_type_int    cch = n_explorer_path_get_cch( hwnd_explorer );
	n_posix_char *ret = n_string_path_new( cch );


	n_explorer_path_get( hwnd_explorer, ret, cch );


	return ret;
}

#define n_explorer_cursor2path_cch(      ) ( MAX_PATH )
#define n_explorer_cursor2path( ret, cch ) n_explorer_path_get( n_win_cursor2hwnd(), ret, cch )

n_posix_char*
n_explorer_cursor2path_new( void )
{

	// [!] : you need to n_string_path_free() a returned variable

	n_type_int    cch = n_explorer_cursor2path_cch();
	n_posix_char *ret = n_string_path_new( cch );


	n_explorer_cursor2path( ret, cch );


	return ret;
}


#endif // _H_NONNON_WIN32_EXPLORER

