// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// [ Mechanism ]
//
//	[ WM_CREATE ]
//
//	n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS,  "", &hgui );
//
//	[ WndProc() ]
//
//	n_win_group_proc( ..., hgui )




#ifndef _H_NONNON_WIN32_WIN_GROUPBOX
#define _H_NONNON_WIN32_WIN_GROUPBOX




#include "./gdi/doublebuffer.c"

#include "./win.c"

#include "./uxtheme.c"




#define N_WIN_GROUPBOX_TEXT_OFFSET ( 7 )




void
n_win_group_box( HWND hwnd, HDC hdc, RECT *rect, COLORREF color )
{

	//n_win_box( hwnd, hdc, rect, color );

	n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );

	u32 argb = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color ) );

	n_bmp_box( bmp, x,y,sx,sy, argb );


	return;
}

// internal
void
n_win_group_draw( HWND hgui, HDC hdc_override, RECT *rect )
{

	n_type_gfx x,y,sx,sy; n_win_rect_expand_size( rect, &x, &y, &sx, &sy );


	// [x] : flicker prevention : n_gdi_doublebuffer_32bpp_simple_init() only

	HDC hdc = n_gdi_doublebuffer_32bpp_simple_init( hgui, sx,sy );


	n_uxtheme uxtheme; n_uxtheme_zero( &uxtheme );
	n_uxtheme_init( &uxtheme, hgui, L"BUTTON" );


	COLORREF color_bg = n_win_darkmode_systemcolor_ui( COLOR_BTNFACE );
	COLORREF color_fg = n_win_darkmode_systemcolor_ui( COLOR_BTNTEXT );

	n_win_group_box( hgui, hdc, rect, n_win_darkmode_systemcolor( COLOR_BTNFACE ) );


	n_posix_char *text = n_win_text_new( hgui );

	n_type_gfx text_sy = 0; n_win_stdsize_text( hgui, text, NULL, &text_sy );
	n_type_gfx half_sy = text_sy / 2;

	RECT r;
	if ( n_posix_false == n_string_is_empty( text ) )
	{
		n_win_rect_set( &r, x, y + half_sy, sx, sy - half_sy );
	} else {
		n_win_rect_set( &r, x, y, sx, sy );
	}

	if ( n_win_fluent_ui_onoff )
	{

		n_bmp *bmp = &n_gdi_doublebuffer_32bpp_instance.bmp;

		u32 bg = n_bmp_alpha_visible_pixel( n_bmp_colorref2argb( color_bg ) );
		u32 mg = n_win_darkmode_systemcolor_colorref2argb_ui( COLOR_BTNSHADOW );

		n_type_gfx round = n_win_fluent_ui_round_param( hgui );
		n_type_gfx frame = (n_type_gfx) trunc( n_win_scale( hgui ) );

		n_type_gfx ty  =  y + ( text_sy / 2 );
		n_type_gfx tsy = sy - ( text_sy / 2 );

		n_bmp_ui_roundframe( bmp, x,ty,sx,tsy, round,frame, mg,bg );

	} else
	if ( uxtheme.onoff )
	{

		int part  = BP_GROUPBOX;
		int state = GBS_NORMAL;

		uxtheme.DrawThemeBackground( uxtheme.htheme, hdc, part,state, &r, NULL );

	} else {

		DrawEdge( hdc, &r, EDGE_ETCHED, BF_RECT );

	}


	{

		SetBkColor  ( hdc, color_bg );
		SetTextColor( hdc, color_fg );

		n_type_gfx scale  = (n_type_gfx) trunc( n_win_scale( hgui ) );
		n_type_gfx offset = N_WIN_GROUPBOX_TEXT_OFFSET * scale;

		TextOut( hdc, x + offset, y, text, (int) n_posix_strlen( text ) );

	}

	n_string_free( text );


	n_uxtheme_exit( &uxtheme, hgui );


	if ( hdc_override == NULL )
	{
		n_gdi_doublebuffer_32bpp_simple_exit();
	} else {
		BitBlt( hdc_override, 0,0,sx,sy, hdc, 0,0, SRCCOPY );
		n_gdi_doublebuffer_32bpp_simple_cleanup();
	}


	return;
}

void
n_win_group_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam, HWND hgui )
{

	switch( msg ) {


	case WM_DRAWITEM :
	{

		DRAWITEMSTRUCT *di = (void*) lparam;
		if ( di == NULL ) { break; }

		if ( hgui != di->hwndItem ) { break; }


		// [x] : don't use di->hDC : draw error happens

		n_win_group_draw( hgui, NULL, &di->rcItem );

	}
	break;


	} // switch


	return;
}


#endif // _H_NONNON_WIN32_WIN_GROUPBOX


/*


#include "../project/macro.c"


LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	static HWND hgui;


	switch( msg ) {


	case WM_CREATE :


		n_project_darkmode();
		//n_win_darkmode_onoff = n_posix_true;


		// Window

		n_win_init_literal( hwnd, "Nonnon", "", "" );


		n_win_gui_literal( hwnd, N_WIN_GUI_CANVAS, "Nonnon", &hgui );


		// Style

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );

		n_win_stdfont_init( &hgui, 1 );


		// Size

		n_win_set( hwnd, NULL, 200,200, N_WIN_SET_CENTERING );
		n_win_move( hgui, 20,20,100,100, n_posix_true );


		// Display

		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		n_win_stdfont_exit( &hgui, 1 );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	n_win_group_proc( hwnd,msg,wparam,lparam, hgui );


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

*/

